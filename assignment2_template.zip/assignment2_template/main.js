function rowConverter(row) {
  return {
    app_name: row.app_name,
    downloads: parseInt(row.downloads),
    average_rating: parseFloat(row.average_rating),
    thirty_day_keep: parseFloat(row.thirty_day_keep)
  }
}

window.onload = function () {
  d3.csv('fake_app_download_rating.csv', rowConverter)
    .then((dataset) => {

      let w = 600;
      let h = dataset.length * 24;

  // sort the data by downloads
  // uses built-in Array.sort() with comparator function
  dataset.sort((a,b) => b.downloads - a.downloads);

  let chart1 = d3.select('#chart1')
    .attr('width', w)
    .attr('height', h);

  // our range is limited from 0 to width - 100, 
  // which is for the 80 pixels on left for axis and 
  // 20 pixels on right for padding
  let xScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, (d) => d.downloads)])
    .rangeRound([0, w - 100]);

  // using scale band to work with nominal values 
  // the Array.map() call allows us to get a new array
  // by calling a function on each item of the source array 
  // here it pulls out the app_name
  let yScale = d3.scaleBand()
    .domain(dataset.map((d) => d.app_name))
    .rangeRound([20, h - 20]);

  // d3 allows scaling between colors
  let colorScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, (d) => d.downloads)])
    .range(['#ccf', '#88d']);

  chart1.selectAll('rect')
    .data(dataset)
    .enter()
    .append('rect')
    .classed('bar', true)
    .attr('x', (d,i) => xScale(i) + 80)
    .attr('y', (d) => yScale(d.app_name))
    .attr('width', 0)
    .attr('height', 20)
    .attr('fill', '#88d');

  // AXES
  chart1.append('g')
    .attr('class', 'axis')
    .attr('transform', `translate(80, ${h - 20})`)
    .call(d3.axisBottom(xScale));

  chart1.append('g')
    .attr('class', 'axis')
    .attr('transform', `translate(80,0 )`)
    .call(d3.axisLeft(yScale));

    
  let itemDelay = 1000 / dataset.length;

    d3.selectAll('rect')
    .data(dataset)
    .transition('bars')
    .duration(250)
    .delay((d,i) => i * itemDelay) // delay: use function to stagger delay per item
    .ease(d3.easeLinear)    // study easing options at https://bl.ocks.org/mbostock/248bac3b8e354a9103c4
                            // also open JS console and type d3.ease and look at the completions for quick reference
    
    .on('start', function() {
      d3.select(this)              // get the bound element for the current datum
        .style('fill', (d) => colorScale(d.downloads))    // set the fill to black so we can gradually transition back to purple
    })
    .attr('y', (d) => yScale(d.app_name))
    .attr('width', (d) => xScale(d.downloads))
    .style('fill', '#88d')
    .on('end', function() {
      d3.select(this)
        .style('fill', (d) => colorScale(d.downloads)) 
        .style('stroke', 'none');
    });
  });
}
